<div id="message" class="updated fade">
<p>
  <strong>
    <?php _e("Mise à jour des informations effectuée avec succès.","wip");?>
  </strong>
</p>
</div>