<div id="message" class="deleted fade">
<p>
  <strong>
    <?php _e("Un soucis s'est déroulé lors de cette action.","wip");?>
  </strong>
</p>
</div>